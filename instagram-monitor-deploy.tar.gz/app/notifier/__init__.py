"""Telegram notification system."""
